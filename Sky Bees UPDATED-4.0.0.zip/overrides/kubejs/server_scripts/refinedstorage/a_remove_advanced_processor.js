onEvent('recipes', event => {
  event.remove({output: 'refinedstorage:advanced_processor', type: 'minecraft:smelting'})
})
