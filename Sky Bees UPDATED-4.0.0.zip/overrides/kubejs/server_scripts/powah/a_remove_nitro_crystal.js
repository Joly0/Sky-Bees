onEvent('recipes', event => {
  event.remove({id: 'powah:energizing/nitro_crystal'})
})
