onEvent('recipes', event => {
  event.custom(
    {
  "type": "botania:mana_infusion",
  "input": {
    "tag": "minecraft:coals"
  },
  "output": {
    "item": "powah:dielectric_paste"
  },
  "mana": 50
}
)
})
