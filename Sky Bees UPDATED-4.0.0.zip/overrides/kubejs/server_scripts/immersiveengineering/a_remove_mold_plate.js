onEvent('recipes', event => {
  event.remove({id: 'immersiveengineering:blueprint/mold_plate'})
})
