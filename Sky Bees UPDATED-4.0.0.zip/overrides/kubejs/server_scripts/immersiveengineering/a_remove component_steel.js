onEvent('recipes', event => {
  event.remove({id: 'immersiveengineering:blueprint/component_steel'})
})
